﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ScriptingTest;

namespace ScriptingTest
{
    /// <summary>
 /// bla
 /// </summary>
    public class StartupListObject
    {
        /// <summary>
        /// bla
        /// </summary>
        public string NetworkPosition;
        /// <summary>
        /// bla
        /// </summary>
        public string Channel;
        /// <summary>
        /// bla
        /// </summary>
        public string Comment;
        /// <summary>
        /// bla
        /// </summary>
        public string Timeout;
        /// <summary>
        /// bla
        /// </summary>
        public string Ccs;
        /// <summary>
        /// bla
        /// </summary>
        public string Index;
        /// <summary>
        /// bla
        /// </summary>
        public string SubIndex;
        /// <summary>
        /// bla
        /// </summary>
        public string Data;
        /// <summary>
        /// bla
        /// </summary>
        public string Size;
        /// <summary>
        /// bla
        /// </summary>
        public StartupListObject(string networkposition, string channel, string comment, string timeout, string ccs, string index, string subindex, string data, string size)
        {
            Comment = comment; Timeout = timeout; Ccs = ccs; Index = index; SubIndex = subindex; Data = data; NetworkPosition = networkposition; Channel = channel; ; Size = size;
        }


    }
    /// <summary>
    /// Actual status of the Script
    /// </summary>
    static public class CSV_Reader
    {
        /// <summary>
        /// Project Path if already exist
        /// </summary>
        static public string ProjectPath;
        /// <summary>
        /// EthernetIP adaptor template. Must have this
        /// </summary>
        static public string EthernetIPTemplate;
        /// <summary>
        /// auto
        /// </summary>
        static public List<string[]> AutoRenameInEtherCATList;// = new List<string[]>();
        /// <summary>
        /// auto
        /// </summary>
        static public List<string[]> AutoRenameInEIPList;// = new List<string[]>();
        /// <summary>
        /// auto
        /// </summary>
        static public List<StartupListObject> AutoEtherCATSettings;// = new List<StartupListObject>();
        /// <summary>
        /// Actual status of the Script
        /// </summary>
        static public void ReadConfigCSV()
        {
            AutoRenameInEtherCATList = new List<string[]>();
            AutoRenameInEIPList = new List<string[]>();
            AutoEtherCATSettings = new List<StartupListObject>();

            string localFolder = System.IO.Directory.GetCurrentDirectory();
            string filePath = localFolder + @"\Settings.txt";
            if (System.IO.File.Exists(filePath))
            {
                using (var reader = new StreamReader(filePath))
                {
                    //List<string> listA = new List<string>();
                    //List<string> listB = new List<string>();
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        //listA.Add(values[0]);
                        //listB.Add(values[1]);
                        if (values[0] == "TwinCATProjectPath")
                        {
                            if (values[1] == "UseLocalPath")
                            {
                                ProjectPath = localFolder + @"\" + values[2];
                            }
                            else
                                ProjectPath = values[1];
                        }
                        if (values[0] == "EthernetIPTemplate")
                        {
                            if(values[1] == "UseLocalPath")
                            {
                                EthernetIPTemplate = localFolder + @"\" + values[2];
                            }
                            else
                                EthernetIPTemplate = values[1];
                        }
                        if (values[0] == "CharReplaceInEtherCAT" && values.Count() == 3)
                        {
                            string[] replacechars = new string[2];
                            replacechars[0] = values[1];
                            replacechars[1] = values[2];
                            AutoRenameInEtherCATList.Add(replacechars);
                        }
                        if (values[0] == "CharReplaceInEIP" && values.Count() == 3)
                        {
                            string[] replacechars = new string[2];
                            replacechars[0] = values[1];
                            replacechars[1] = values[2];
                            AutoRenameInEIPList.Add(replacechars);
                        }
                        if (values[0] == "EP7402" && values.Count() > 2)
                        {
                            for (int x = 0; x < values.Count(); x++) 
                            {
                                string column = values[x];
                                if (column.StartsWith("{"))
                                {
                                    column = column.TrimStart('{');
                                    column = column.TrimEnd('}');
                                    
                                    string[] subcolumn = column.Split(';');                                 
                                    StartupListObject StartupListObject2 = new StartupListObject(values[1], values[2], subcolumn[0], "0", "1", subcolumn[1].Split(':')[0], subcolumn[1].Split(':')[1], subcolumn[2], subcolumn[3]);
                                    AutoEtherCATSettings.Add(StartupListObject2);
                                }
                            }
                            //string[] replacechars = new string[values.Count()];
                           
                            //AutoRenameInEIPList.Add(replacechars);
                        }


                    }
                }
            }
        }
    }
}
